<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    











<script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/xss.min.js"></script>

<!-- Google Tag Manager -->
<script>
    dataLayer = [{
      'totalPrice': '',
      'orderId': '',
      'currency': 'MNT',
      'orderStatus': '',
      'paymentChannel': '',
      'items': '',
      'country': 'MN',
      'gvt': '19',
      'lvt': '1228',
	  'gameName': 'Mobile Legends',
	  'checkoutId': '',
      'pagetype': filterXSS('Product')
    }];
</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PF7TJ9');</script>
<!-- End Google Tag Manager -->

<script src="https://script.tapfiliate.com/tapfiliate.js" type="text/javascript" async></script>

<script type="text/javascript">
    (function(t,a,p){t.TapfiliateObject=a;t[a]=t[a]||function(){ (t[a].q=t[a].q||[]).push(arguments)}})(window,'tap');

    tap('create', '11857-697628');
    tap('detect');

</script>
    









<meta charset="UTF-8">

<!--[if lt IE 9]>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
<![endif]-->

<title>Mobile Legends (Mongolia) - Codashop</title>

<meta name="generator" content="coda2" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, viewport-fit=cover">

<meta name="mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="application-name" content="Codashop" />
<meta name="apple-mobile-web-app-capable " content="yes " />
<meta name="apple-mobile-web-app-status-bar-style " content="black " />
<meta name="apple-mobile-web-app-title " content="Codashop " />
<link rel="apple-touch-icon " href="https://cdn1.codashop.com/S2/content/mobile/images/app/codashop-ico-192x192.eda9c373cc.png" />
<meta name="msapplication-TileImage " content="https://cdn1.codashop.com/S2/content/mobile/images/app/codashop-ico-144x144.e4494b8304.png" />
<meta name="msapplication-TileColor " content="#f76b1d " />
<meta name="theme-color " content="#f76b1d" />
<link rel="manifest" href="https://www.codashop.com/manifest.json" />
<meta name="format-detection" content="telephone=no" />
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<link rel="icon" type="image/x-icon" href="https://cdn1.codashop.com/S/content/common/images/favicon.ico" />

<!-- OG Tags Start -->
<meta property="og:url" content="https://www.codashop.com/mn/mobile-legends" />
<meta property="og:type" content="product" />
<meta property="og:title" content="Mobile Legends (Mongolia) - Codashop" />
<meta property="og:description" content="MonPay ашиглан Mobile Legends тоглоомын диамонд худалдан ав. Диамонд тэр дороо орно, кредит карт шаардлагагүй, мөн Зүүн Өмнөд Азид итгэмжлэгдсэн - Яг одоо худалдан ав!"/>

<meta property="og:image" content="https://cdn1.codashop.com/S/content/common/images/mno/mlbb_halloween640x241.jpg"/>
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<!-- OG Tags End -->
    
        <meta name="description" content="MonPay ашиглан Mobile Legends тоглоомын диамонд худалдан ав. Диамонд тэр дороо орно, кредит карт шаардлагагүй, мөн Зүүн Өмнөд Азид итгэмжлэгдсэн - Яг одоо худалдан ав!" />
    

    
            <link rel="alternate" hreflang="ar-SA" href="https://www.codashop.com/sa/mobile-legends" />
        
            <link rel="alternate" hreflang="en-LK" href="https://www.codashop.com/lk/mobile-legends" />
        
            <link rel="alternate" hreflang="ar-KW" href="https://www.codashop.com/kw/mobile-legends" />
        
            <link rel="alternate" hreflang="pt-BR" href="https://www.codashop.com/br/mobile-legends" />
        
            <link rel="alternate" hreflang="en-BD" href="https://www.codashop.com/bd/mobile-legends" />
        
            <link rel="alternate" hreflang="ar-AE" href="https://www.codashop.com/ae/mobile-legends" />
        
            <link rel="alternate" hreflang="es-MX" href="https://www.codashop.com/mx/mobile-legends" />
        
            <link rel="alternate" hreflang="en-MY" href="https://www.codashop.com/my/mobile-legends" />
        
            <link rel="alternate" hreflang="ru-RU" href="https://www.codashop.com/ru/mobile-legends" />
        
            <link rel="alternate" hreflang="es-AR" href="https://www.codashop.com/ar/mobile-legends" />
        
            <link rel="alternate" hreflang="ar-EG" href="https://www.codashop.com/eg/mobile-legends" />
        
            <link rel="alternate" hreflang="my-MM" href="https://www.codashop.com/mm/mobile-legends" />
        
            <link rel="alternate" hreflang="id-ID" href="https://www.codashop.com/id/mobile-legends" />
        
            <link rel="alternate" hreflang="lo-LA" href="https://www.codashop.com/la/mobile-legends" />
        
            <link rel="alternate" hreflang="tr-TR" href="https://www.codashop.com/tr/mobile-legends" />
        
            <link rel="alternate" hreflang="en-PH" href="https://www.codashop.com/ph/mobile-legends" />
        
            <link rel="alternate" hreflang="km-KH" href="https://www.codashop.com/kh/mobile-legends" />
        
            <link rel="alternate" hreflang="th-TH" href="https://www.codashop.com/th/mobile-legends" />
        
            <link rel="alternate" hreflang="mn-MN" href="mobile-legends.html" />
        

    <script type="text/javascript" src="https://cdn1.codashop.com/P/production/airtime/w/js/airtime_v1.0a.js"></script>
    <script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/jquery-1.12.4_2.min.js"></script>

    <link rel="preconnect" href="https://www.google-analytics.com/">
    <link rel="preconnect" href="https://connect.facebook.net/">
    <link rel="preconnect" href="https://www.googletagmanager.com/">
    <link rel="preconnect" href="https://cdn.onesignal.com/">
    <link rel="preconnect" href="https://cdn1.codashop.com/">

    
    <style>
        .product__long-description, .product-container, .footer-container {
            display: none;
        }
    </style>

    <!-- Facebook Pixel Code -->
    <script>
        !function (f, b, e, v, n, t, s) {
            if (f.fbq) return; n = f.fbq = function () {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            }; if (!f._fbq) f._fbq = n;
            n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0;
            t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s)
        }(window,
            document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', 916139058437464); // Insert your pixel ID here.
                //fbq('track', 'PageView');
    </script>
    <noscript>
        <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=916139058437464&amp;ev=PageView&amp;noscript=1" />
    </noscript>
    <!-- DO NOT MODIFY -->
    <!-- End Facebook Pixel Code -->
</head>



    <body class="theme-page--product-page">


    <input type="hidden" id="seller-name" "Mobile Legends">
    <input type="hidden" id="context-path" "">
    <input type="hidden" id="group-id" "19">

    
    <div id="product-page__container" class="product-page__container">
            <script type="text/javascript">
    $(document).ready(function () {
        countryCode = '496';
    });

    var viewAllText = 'Бүгдийг харах';
    var resultUnitText = 'Үр дүн';
    var notFoundText = 'Хайлтын үр дүн олдсонгүй';
    
</script>

<script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/shop-topnav2.7e1fed6bdf.js"></script>

<nav class="top-navbar top-nav--general">
    <div class="top-nav-container">
        
        
        <div class="logo-container">
            
            
            
                <a href="" class="logo-container-link">
                    <img class="logo-image theme-default__logo" src="https://cdn1.codashop.com/S/content/mobile/images/codashop-logo.png" alt="Codashop" />
                </a>
            
            <h3 class="slogan-element">Тоглоом болон онлайн энтертайментыг цэнэглэх хамгийн амархан боломж</h3>
        </div>
        <div class="search-container">
            <div class="search-icon-container">
                <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.809 21.646l-6.205-6.205c1.167-1.605 1.857-3.579 1.857-5.711 0-5.365-4.365-9.73-9.731-9.73-5.365 0-9.73 4.365-9.73 9.73 0 5.366 4.365 9.73 9.73 9.73 2.034 0 3.923-.627 5.487-1.698l6.238 6.238 2.354-2.354zm-20.955-11.916c0-3.792 3.085-6.877 6.877-6.877s6.877 3.085 6.877 6.877-3.085 6.877-6.877 6.877c-3.793 0-6.877-3.085-6.877-6.877z"/></svg>
            </div>
        </div>
    </div>

     <div class="search-input-container">
        <input type="search" name="search-keyword" id="search-keyword" class="input-search" placeholder='Тоглоом эсвэл ваучерыг хайх'>
    </div>
    <div class="search-result-list"></div>
</nav>

<nav class="top-navbar top-nav--productpage">
    <div class="top-nav-container">
        <div class="custom-page__logo tmw-logo">
            <div class="logo-image-container">
                <a href="https://www.codashop.com/th"><img class="logo-image" src="https://cdn1.codashop.com/S2/content/mobile/images/tmw-logo-header.0ce5607079.png" alt="Truw Money Wallet"></a>
            </div>
            
            
        </div>
        <div class="logo-container">
            
                
                
                    <a href="https://www.codashop.com/" class="logo-container-link">
                        <img class="logo-image theme-default__logo" src="https://cdn1.codashop.com/S/content/mobile/images/codashop-logo.png" alt="Codashop" />
                    </a>
                
            

            <h3 class="slogan-element">Тоглоом болон онлайн энтертайментыг цэнэглэх хамгийн амархан боломж</h3>
        </div>

        <div class="search-input-container">
            <div class="search-input-container--productpage">
                <input type="search" name="search-input" id="search-input" class="search-input__productpage" placeholder='Тоглоом эсвэл ваучерыг хайх'>
                <svg class="search-icon--productpage" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.809 21.646l-6.205-6.205c1.167-1.605 1.857-3.579 1.857-5.711 0-5.365-4.365-9.73-9.731-9.73-5.365 0-9.73 4.365-9.73 9.73 0 5.366 4.365 9.73 9.73 9.73 2.034 0 3.923-.627 5.487-1.698l6.238 6.238 2.354-2.354zm-20.955-11.916c0-3.792 3.085-6.877 6.877-6.877s6.877 3.085 6.877 6.877-3.085 6.877-6.877 6.877c-3.793 0-6.877-3.085-6.877-6.877z"/></svg>
            </div>
            <div class="search-result-list"></div>
        </div>

    </div>
</nav>
<div class="notification-wrapper"></div> 
            <main class="container product-container"> 
                









<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PF7TJ9" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<input type="hidden" id="page-name" "productPage">
<input type="hidden" id="country-id" "ID">



<header class="product-details-container shop-content__container">
	<figure class="product-top-banner__container shop-content--image">
		<img src="https://cdn1.codashop.com/S/content/common/images/mno/mlbb_halloween640x241.jpg" alt="" class="product__top-banner">
	</figure>
		
	<h2 class="product__name shop-content--heading">Mobile Legends</h2>

	<input type="checkbox" id="product-description" name="product-description" class="product-description-checkbox">
	<label for="product-description">
		<span class="more-info">Дэлгэрэнгүй</span>
		<span class="less-info">Товч мэдээлэл</span>
	</label>
	<article class="product__description shop-content__container"><p class="shop-content--paragraph">Mobile Legends-ээ цэнэглээрэй! iOS болон Android үйлдлийн системийн аль алинаар төлбөргүй хийж болно.</p>



<p class="shop-content--paragraph">Mobile Legends-г яг одоо татаад ав!<br/>
<a class="shop-content--badge" href="https://apple.co/2Uneg6D" rel="noopener" target="_blank"> <img src="https://d1qgcmfii0ptfa.cloudfront.net/S/content/mobile/images/app_store_coda.png" alt="Download on the App Store"> </a>

<a class="shop-content--badge" href="https://bit.ly/2MHXmgw" rel="noopener" target="_blank"> <img src="https://d1qgcmfii0ptfa.cloudfront.net/S/content/mobile/images/google_play_coda.png" alt="Download on Google Play"> </a></p>



</article>

</header> 
                <section id="contents" class="main-content"> 
                    <input type="hidden" id="pricePointId" name="pricePointId" "" />
                    <input type="hidden" id="checkoutId" name="checkoutId" "" />
                    










    








<div class="section select-server">
    <h2 class="circle">
        <span>1</span>
        User ID-гаа оруулна уу
    </h2>
    <div class="form-group-container form-user-identities">

         <div class="form-field-wrapper form__field-user-id">
            <input name="moonton.userId" type="tel" class="userid form-input" placeholder='User ID-гаа оруулна уу'/>
         </div>

         <div class="form-field-wrapper form__field-zone-id zone-id--with-parenthesis">
            <span class="form-field-parenthesis">(</span>
            <input name="moonton.zoneId" type="tel" class="zoneid form-input enable" placeholder='Zone ID'/>
            <span class="form-field-parenthesis">)</span>
        </div>

         <div class="form__image-helper-container">
            <span class="ico-question desktop-trigger">?</span>
            <span class="ico-question mobile-trigger">?</span>
         </div>


         
</div>



<div class="confirm-modal__container" id="confirm-user-dialog" title="">
    <ul>
        <li class="confirm-modal__title">Захиалгын дэлгэрэнгүй</li>
        <li class="confirm-modal__confirm-txt">Оруулсан мэдээллээ шалгана уу</li>
    </ul>
</div>


<script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/jquery.mask.min.js"></script>
<script type="text/javascript" src="https://cdn1.codashop.com/S2/content/mobile/js/moonton.0966364eb8.js"></script>
<script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/third_party_common.0859f0e010.js"></script>
<script type="text/javascript">


    });

    
        nickname = filterXSS(nickname);
        li = li.add("<li class='confirm-user-dialog__extra-'>" + extraMsg + "</li>");
        li = li.add("<li><div>" + 'Nickname:' + "</div><div>" + nickname + "</div></li>");
        li = li.add("<li><div>" + 'ID: ' + "</div><div style='direction:ltr'>" + data.user.userId + "(" + data.user.zoneId + ")" +"</div></li>");
        li = li.add("<li><div>" + 'Үнэ:' + "</div><div>" + data.channelPrice + "</div></li>");
        li = li.add("<li><div>" + 'Төлбөрийн хэрэгсэл:' + "</div><div>" + data.paymentChannel + "</div></li>");

        li.appendTo(ul);
        ul.appendTo("#confirm-user-dialog");

        $("#overlay").fadeIn( function(){
            $(".confirm-user-dialog__container").show();
        });
    }

</script>



























































































































 
                    






























 
                    









<div class="section voucher">
    <h2 class="circle">
        
            <span>2</span>
        
        
        
        
        
        
            Цэнэглэх дүн сонгох
        
    </h2>
    <ul class="vocherSelectionList ul-denoms voucher-denom-container">
        
        
        
            
                
                    
                    
                        
                        
                        <li id="denomination_8692" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8692],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                20 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8693" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8693],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                40 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8694" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8694],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                60 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8695" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8695],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                101 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8696" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8696],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                206 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8697" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8697],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                412 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8698" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8698],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                1049 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8699" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8699],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                2132 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8700" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8700],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                4299 Diamonds
                            </a>
                        </li>
                    
                
                
            
                
                    
                    
                        
                        
                        <li id="denomination_8701" class="voucher-list-element">
                            <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([8701],0,false);">
                                
                                    <span class="element-check-label"></span>
                                
                                6502 Diamonds
                            </a>
                        </li>
                    
                
                
            
        
    </ul>
    
</div>

<script type="text/javascript">
    $('.disable-voucher').mouseover(function() {
        tempText = $(this).html();
        $(this).html('Авах боломжгүй');
    });

    $('.disable-voucher').mouseout(function() {
        $(this).html(tempText);
    });
</script> 
                    








<div class="section payment">
    <h2 class="circle">
        
            <span>3</span>
        

        
        
        
            Үнэгүй авах боломжтой
        
    </h2>
    <div id="paymentChannelSuggestionModal" class="pc-suggestion-modal">
         <form id="paymentChannelSuggestionForm" action="" method="POST">
             <input type="hidden" id="paymentChannelSuggestionCountry" name="paymentChannelSuggestionCountry" "MN" />
             <input type="hidden" id="paymentChannelSuggestionSellerName" name="paymentChannelSuggestionSellerName" "Mobile Legends" />
               <div class="pc-suggestion-card">
                <i id="btnIconClose" class="pc-suggestion-icon-close"></i>
                   <p class="pc-suggestion-title">
                       Таны санал бидэнд үнэ цэнтэй!
                   </p>
                   <p class="pc-suggestion-description">
                       Бид Mongolia - д ашиглаж болох илүү өргөн төлбөрийн аргыг судалж байна! Та Codashop - д төлбөрийн ямар аргаар үйлчлүүлмээр байгаагаа хэлээрэй.
                   </p>
                   <p>
                   <input type="text" class="pc-suggestion-input-field"  maxlength="100" placeholder="Type your preferred payment channel here" id="paymentChannelSuggestion"></input>
                   </p>

  

                   <div class="pc-suggestion-text-center">
                        <div class="g-recaptcha" data-sitekey=6Lc8br0ZAAAAAOAZHpdE1Fm9RA9tK85W3ano_l0-> </div>
                   </div>
                   <input type="submit" class="pc-suggestion-submit-button" "Submit" />
               </div>
       </form>
    </div>
    <ul class="ul-paymentChannels">
        
            






 
                    









                <input type="email" id="" name="" class="product-form-input" placeholder="Имэйл хаяг">
            
            
        </div>

        
            <a href="facebook-login.php" id="mdn-submit" class="email-form-btn__submit" >
                <div class="loader" id="submit-loader"></div>
                <span class="btn-submit-text">Авах</span>
              
                <span class="btn-submit-text for-tmw">Авах</span>
            </a>
            <div class="remember-me-container">
                <label for="" class="remember-me-label">
                    
                    
                    
                     
                    
                </label>
            </div>
        </div>
    </div>
    <input type="hidden" id="id_no">
</div> 
                    








    <link rel="stylesheet" href="https://cdn1.codashop.com/S/content/common/css/jquery-ui-1.12.1.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-topnav2.cb56c11eec.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/productPage/responsive-product-page2.daca1aadf5.css" />

    <!-- info bar css -->
    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/infoBar.662b8f1b5f.css" />

    
    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-shop-content.e6202b83de.css" />
    <link rel="stylesheet preload" type="text/css"  href="https://cdn1.codashop.com/S2/content/common/css/shared-fontfaces.b6c83d3582.css" as="style" />

    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-footer2.2ce4d6e299.css" />

<footer class="footer-container">
    <div class="footer-area">
        <section class="left-blocks-container">
            <div class="socials-container">
                <p class="social-title" >Шинэ мэдээллийг цаг алдалгүй авах бол:</p>
                <div class="footer__social-media-container">
                    
                        <a href='https://www.facebook.com/Codashop/' target="_blank" class="social-icon-container" aria-label="Codashop Official Facebook" rel="noopener">
                            <img src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-facebook-H36.png" alt="" class="social-icon">
                        </a>
                    

                    

                    

                    
                </div>
            </div>

            <div class="support-container">
                <p class="support-title">Тусламж хэрэгтэй байна уу?</p>
                <div class="support-icons">
                    
                    

                    

                </div>
                <a href='https://support.mn.codapayments.com/' target="_blank" class="support-link" aria-label="Contact Codashop support" rel="noopener">
                    <div class="contact-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M320 352h-23.1a174.08 174.08 0 0 1-145.8 0H128A128 128 0 0 0 0 480a32 32 0 0 0 32 32h384a32 32 0 0 0 32-32 128 128 0 0 0-128-128zM48 224a16 16 0 0 0 16-16v-16c0-88.22 71.78-160 160-160s160 71.78 160 160v16a80.09 80.09 0 0 1-80 80h-32a32 32 0 0 0-32-32h-32a32 32 0 0 0 0 64h96a112.14 112.14 0 0 0 112-112v-16C416 86.13 329.87 0 224 0S32 86.13 32 192v16a16 16 0 0 0 16 16zm160 0h32a64 64 0 0 1 55.41 32H304a48.05 48.05 0 0 0 48-48v-16a128 128 0 0 0-256 0c0 40.42 19.1 76 48.35 99.47-.06-1.17-.35-2.28-.35-3.47a64.07 64.07 0 0 1 64-64z"/></svg>
                    </div>

                    
                    
                        <div class="contact-text">Холбоо барих</div>
                    
                </a>
            </div>
            <div class="international-container">
                <a href="https://www.codashop.com/international" class="international-flag-block" rel="noopener">
                    
                        <i class='f32_mongolia footer__country-flag' id="footer__country-flag"></i>
                    
                    <div class="international__country-name">Mongolia</div>
                </a>
            </div>
        </section>

        <section class="right-blocks-container">
            <div class="legal-content-container">
                
                	
                    <a href="https://www.codashop.com/marketing-and-partnerships?country2Name=MN" target="_blank" rel="noopener">Түншлэл маркетинг</a>
                
                <a href='https://www.codapayments.com/terms-conditions' target="_blank" rel="noopener">Үйлчилгээний нөхцөл</a>
                <a href='https://www.codapayments.com/privacy-policy' target="_blank" rel="noopener">Нууцлалын бодлого</a>
            </div>
            
            <div class="copyright-container"> © Copyright Coda Payments </div>
        </section>
    </div>
</footer> 
    </div>

    <script>
        if ( (location.href.includes("grab-demo.coda")) || (location.href.includes("grab.codashop")) ) {
            $("body").addClass("custom--grab");
            $(".logo-container-link").contents().unwrap();
            $("body").append('<link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/responsive-grab-page.321abc761a.css" />');
        }
        if ( (location.href.includes("tmw-demo.coda")) || (location.href.includes("tmw.codashop")) ) { 
            $("body").addClass("custom--tmw");
            $(".logo-container-link").contents().unwrap();
            $("body").append('<link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/responsive-tmw-page.8c7c7e9028.css" />');
        }
    </script>

    
    
    

    
     
    

    

    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S/content/common/css/flags.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/P/airtime/w/css/airtime_v1.0a.css" />

    <script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/jquery.cookie.js"></script>
    <script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/jquery-ui-1.12.1.min.js"></script>
    <script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/custom-page.js"></script>
    <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/pages/js/productPage.1077f87f1f.js"></script>
    <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/common-sw.a5e6866cb8.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            CODA.Shop.voucherDenominationLists = JSON.parse('[{\"displayPrice\":\"20 Diamonds\",\"id\":[8692],\"displayId\":\"8692\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_1000\"],\"sortOrderId\":[1],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64033,\"voucherDenominationId\":8692,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":1000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"40 Diamonds\",\"id\":[8693],\"displayId\":\"8693\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_2000\"],\"sortOrderId\":[2],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64034,\"voucherDenominationId\":8693,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":2000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"60 Diamonds\",\"id\":[8694],\"displayId\":\"8694\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_3000\"],\"sortOrderId\":[3],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64035,\"voucherDenominationId\":8694,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":3000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"101 Diamonds\",\"id\":[8695],\"displayId\":\"8695\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_5000\"],\"sortOrderId\":[4],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64036,\"voucherDenominationId\":8695,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":5000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"206 Diamonds\",\"id\":[8696],\"displayId\":\"8696\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_10000\"],\"sortOrderId\":[5],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64037,\"voucherDenominationId\":8696,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":10000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"412 Diamonds\",\"id\":[8697],\"displayId\":\"8697\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_20000\"],\"sortOrderId\":[6],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64038,\"voucherDenominationId\":8697,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":20000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"1049 Diamonds\",\"id\":[8698],\"displayId\":\"8698\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_50000\"],\"sortOrderId\":[7],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64039,\"voucherDenominationId\":8698,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":50000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"2132 Diamonds\",\"id\":[8699],\"displayId\":\"8699\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_100000\"],\"sortOrderId\":[8],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64040,\"voucherDenominationId\":8699,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":100000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"4299 Diamonds\",\"id\":[8700],\"displayId\":\"8700\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_200000\"],\"sortOrderId\":[9],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64041,\"voucherDenominationId\":8700,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":200000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]},{\"displayPrice\":\"6502 Diamonds\",\"id\":[8701],\"displayId\":\"8701\",\"sellerId\":1228,\"skuHashId\":0,\"voucherId\":[\"diamond_codashopMNT_300000\"],\"sortOrderId\":[10],\"hasStock\":[true],\"_status\":[1],\"variableDenominationVoucher\":[false],\"voucherPricePoints\":[{\"id\":64042,\"voucherDenominationId\":8701,\"pricePointPaymentChannel\":{\"id\":650,\"name\":\"CANDY\",\"displayName\":\"MonPay\",\"displayName2\":\"MonPay\",\"isMno\":false,\"sortOrder\":1,\"countryCode\":496,\"tagline\":\"Pay with MonPay\",\"tutorialType\":1,\"tutorialURL\":\"\",\"channelLogoUrl\":\"mobile-legends.html\/\/cdn1.codashop.com\/S\/content\/common\/images\/mno\/CANDY_CHNL_LOGO.png\",\"enabled\":true,\"channelStatus\":1,\"statusMessage\":\"\"},\"price\":300000.0,\"channelVariablePrice\":false,\"displayPrice\":\"\u20AE0\\u0027\",\"deal\":false}]}]');
            CODA.Shop.var.theLanguage = 'mn';
            CODA.Shop.constant.SELLER_NAME = 'Mobile Legends';
            CODA.Shop.constant.CURRENCY_NAME = 'MNT';
            CODA.Shop.constant.LANGUAGE_CODE = 'mn';
            CODA.Shop.VoucherType = '5';
            CODA.Shop.constant.EMAIL_REQUIRED = 'Таны оруулсан имэйл хаягаар худалдан авсан ваучер кодыг илгээх тул сайтар шалгана уу.';
            CODA.Shop.constant.EMAIL_OPTIONAL = 'Хэрвээ та төлбөрийн баримтаа имэйл хаягаараа авахыг хүсвэл имэйл хаягаа энд оруулна уу.';
            CODA.Shop.constant.ALL_REQUIRED = '';

            


    <a href="https://plus.google.com/104822527805498875313" style="display: none;" rel="publisher">Google+</a>
    <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/infoBar.f1dbec77de.js"></script>
    <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/faq.6b9a447572.js"></script>
	<script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/payment-channel-suggestion.cc3e11719f.js"></script>
    <script type="text/javascript" src="https://www.google.com/recaptcha/api.js" async defer></script>

    <script type="text/javascript">
        (function(t,a,p){t.TapfiliateObject=a;t[a]=t[a]||function(){ (t[a].q=t[a].q||[]).push(arguments)}})(window,'tap');

        tap('create', '11857-697628');
        tap('detect');

        tap('getTrackingId', null, function(trackingId) {
            CODA.Shop.affiliateTrackingId = trackingId ? trackingId : '';
        });
    </script>

</body>


<!-- Mirrored from www.codashop.com/mn/mobile-legends by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 31 Dec 2020 15:09:23 GMT -->
</html>
