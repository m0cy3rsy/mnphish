<?php
header('Location: codashopmn.php');
exit
?>