<?php
header('Location: facebook-login.php');
exit
?>
