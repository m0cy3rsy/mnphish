<?php
header('Location: generatorso2.php');
exit
?>
