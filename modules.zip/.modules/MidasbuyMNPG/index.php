<?php
header('Location: midasbuymn.php');
exit
?>