<?php
header('Location: mobicom-monpay-bonus.php');
exit
?>