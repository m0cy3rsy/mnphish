var commentusername = ["ready", "Giselda Capon", "Fausto Greco", "Lia Piazza", "Anacleto", "Batista", "Priscilla", "Adelia Conti", "Marilena", "Ivo Zetticci", "Chris Jericho", "Abelardo", "Jonathan", "Mafalda", "Sam", "Igor", "Andrew", "Eliano Fallaci", "Ermes", "Calvin", "Concordio", "", "200000", "400000", "600000", "800000", "1000000", "1000000", "1000000", "1000000", "1000000", "1000000", "1000000", "PUBG Unknown Cash", "! ", ". ", ".. ", " ", "Wow", "WOW", "wow", "This trick is amazing ", "this generator is incredible", "This site is awesome ", "this is legit website ", "this website is giving some real stuff ", "thanks for sharing ", "awesome man! you should sell this method", "I can not believe believe that this really works, generated 80000 Unknown Cash", "awesome tool indeed ", "now i dont need to buy PUBG Unknown Cash! thanks a lot ", " ", " ", " ", "", " ", "", "", "", "", "", "", "amazing tool bro. thanks you so much for sharing this ", "thank you admin! works for me!", "the most powerful tool ever! thank you ", "i wonder why this wasn’t on the news. this is stunning tool! ", "thanks a lot dude!!!! WORKS like a charm!!! ", "AWESOME!!", " Thanks for this dude… at first i thought this is some shit again.. thanks a lot! ", "that was amazing!!! thanks a lot for this. ", "works like a charm.. thanks admin.. ", "thanks! I was looking for this in a long time! ", "", "", "", "", "", "", "", "", "", "", "", "", " ", " ", " ", " ", "  ", " ", "", "", "", "", "works! FREAKING AAMZING!! ", "thank you admin! ", "Perfect! this is what i am looking for! ", "amazing job admin… thank you for sharing  ", " ", " ", " ", "thank you", "thanks", "thanks a lot", "thank you so much", "many thanks", "thank you", "thanks", "thanks a lot", ":D ", ":3 ", ":) ", "c: ", "=D ", "=3 ", "=) ", "c= ", "commented", "state-disabled", "addClass", "#commentUsernameLabel", "disabled", "attr", "#commentUsername", "#commentCommentLabel", "#commentComment", "comment1Cookie", "username1Cookie", "username2Cookie", "username3Cookie", "timePosted11Cookie", "timePosted22Cookie", "timePosted33Cookie", "comment2Cookie", "comment3Cookie", "click", "#commentSubmit", "random", "floor", "join", "length", "html", "#username", " ", "#comment", "#timePosted", "Posted few seconds ago", "Posted a minute ago", "Posted ", " minutes ago", "round", "val", "state-error", "getTime", "setTime", "; expires=", "toGMTString", "cookie", "=", "; path=/", ";", "split", "substring", "charAt", "indexOf"];
$(document)[commentusername[0]](main);
usernames = [commentusername[1], commentusername[2], commentusername[3], commentusername[4], commentusername[5], commentusername[6], commentusername[7], commentusername[8], commentusername[9], commentusername[10], commentusername[11], commentusername[12], commentusername[13], commentusername[14], commentusername[15], commentusername[16], commentusername[17], commentusername[18], commentusername[19]];
minPostTime = 10;
maxPostTime = 300;
refreshRate = randomRange(minPostTime * 1000, maxPostTime * 1000);
websiteName = commentusername[20];
website = commentusername[21];
amount = [commentusername[22], commentusername[23], commentusername[24], commentusername[25], commentusername[26], commentusername[27], commentusername[28], commentusername[29], commentusername[30], commentusername[31], commentusername[32]];
resources = [commentusername[33]];
punctuation = [commentusername[34], commentusername[35], commentusername[36], commentusername[37]];
wowKeywords = [commentusername[38], commentusername[39], commentusername[40]];
thisKeywords = [commentusername[41], commentusername[42], commentusername[43], commentusername[44], commentusername[45], commentusername[46]];
thisKeywords2 = [commentusername[47], commentusername[48], commentusername[49], commentusername[50]];
adverbKeywords = [commentusername[51], commentusername[52], commentusername[53], commentusername[54], commentusername[55]];
adjectivesKeywords = [commentusername[56], commentusername[57], commentusername[58], commentusername[59], commentusername[60], commentusername[61]];
iKeywords = [commentusername[62], commentusername[63], commentusername[64], commentusername[65], commentusername[66], commentusername[67], commentusername[68], commentusername[69], commentusername[70], commentusername[71]];
workingKeywords = [commentusername[72], commentusername[73], commentusername[74], commentusername[75], commentusername[76], commentusername[77], commentusername[78], commentusername[79], commentusername[80], commentusername[81], commentusername[82], commentusername[83]];
conjunctionKeywords = [commentusername[84], commentusername[85], commentusername[86], commentusername[87], commentusername[88], commentusername[89]];
conKeywords = [commentusername[90], commentusername[91], commentusername[92], commentusername[93]];
meKeywords = [commentusername[94], commentusername[95], commentusername[96], commentusername[97]];
gotKeywords = [commentusername[98], commentusername[99], commentusername[100]];
thanksKeywords = [commentusername[101], commentusername[102], commentusername[103], commentusername[104], commentusername[105], commentusername[106], commentusername[107], commentusername[108]];
emotes1 = [commentusername[109], commentusername[110], commentusername[111], commentusername[112]];
emotes2 = [commentusername[113], commentusername[114], commentusername[115], commentusername[116]];

function main() {
    if (readCookie(commentusername[117]) != null) {
        $(commentusername[120])[commentusername[119]](commentusername[118]);
        $(commentusername[123])[commentusername[122]](commentusername[121], commentusername[21]);
        $(commentusername[124])[commentusername[119]](commentusername[118]);
        $(commentusername[125])[commentusername[122]](commentusername[121], commentusername[21]);
    };
    if (readCookie(commentusername[126]) != null && readCookie(commentusername[127]) != null) {
        username1 = readCookie(commentusername[127]);
        username2 = readCookie(commentusername[128]);
        username3 = readCookie(commentusername[129]);
        usernameArray = [username1, username2, username3];
        timePosted11 = parseInt(readCookie(commentusername[130]));
        timePosted22 = parseInt(readCookie(commentusername[131]));
        timePosted33 = parseInt(readCookie(commentusername[132]));
        timePosted1 = timePostedTimer(timePosted11);
        timePosted2 = timePostedTimer(timePosted22);
        timePosted3 = timePostedTimer(timePosted33);
        timePostedArray = [timePosted1, timePosted2, timePosted3];
        comment1 = readCookie(commentusername[126]);
        comment2 = readCookie(commentusername[133]);
        comment3 = readCookie(commentusername[134]);
        commentsArray = [comment1, comment2, comment3];
    } else {
        username1 = randomKeyword(usernames);
        username2 = randomKeyword(usernames);
        while (username2 == username1) {
            username2 = randomKeyword(usernames);
        };
        username3 = randomKeyword(usernames);
        while (username3 == username2) {
            username3 = randomKeyword(usernames);
        };
        usernameArray = [username1, username2, username3];
        timePosted11 = randomRange(minPostTime * 1000, maxPostTime * 1000);
        timePosted22 = randomRange(minPostTime * 1000, timePosted11);
        timePosted33 = randomRange(minPostTime * 1000, timePosted22);
        timePosted1 = timePostedTimer(timePosted11);
        timePosted2 = timePostedTimer(timePosted22);
        timePosted3 = timePostedTimer(timePosted33);
        timePostedArray = [timePosted1, timePosted2, timePosted3];
        comment1 = newCommentCreator();
        comment2 = newCommentCreator();
        comment3 = newCommentCreator();
        commentsArray = [comment1, comment2, comment3];
        createCookie(commentusername[127], username1, 0.003);
        createCookie(commentusername[128], username2, 0.003);
        createCookie(commentusername[129], username3, 0.003);
        createCookie(commentusername[126], comment1, 0.003);
        createCookie(commentusername[133], comment2, 0.003);
        createCookie(commentusername[134], comment3, 0.003);
    };
    updateComments();
    var _0x53c9x2 = setInterval(timer, 1000);
    var _0x53c9x3 = setInterval(getNewComment, refreshRate);
    $(commentusername[136])[commentusername[135]](submitEvent);
};

function getNewComment() {
    username1 = username2;
    username2 = username3;
    username3 = randomKeyword(usernames);
    while (username3 == username2 || username3 == username1) {
        username3 = randomKeyword(usernames);
    };
    usernameArray = [username1, username2, username3];
    timePosted11 = timePosted22;
    timePosted22 = timePosted33;
    timePosted33 = 1000;
    timePosted1 = timePostedTimer(timePosted11);
    timePosted2 = timePostedTimer(timePosted22);
    timePosted3 = timePostedTimer(timePosted33);
    timePostedArray = [timePosted1, timePosted2, timePosted3];
    comment1 = comment2;
    comment2 = comment3;
    comment3 = newCommentCreator();
    commentsArray = [comment1, comment2, comment3];
    createCookie(commentusername[127], username1, 0.003);
    createCookie(commentusername[128], username2, 0.003);
    createCookie(commentusername[129], username3, 0.003);
    createCookie(commentusername[126], comment1, 0.003);
    createCookie(commentusername[133], comment2, 0.003);
    createCookie(commentusername[134], comment3, 0.003);
    refreshRate = randomRange(minPostTime * 1000, maxPostTime * 1000);
    updateComments();
};

function newCommentCreator() {
    emotesType = Math[commentusername[138]]((Math[commentusername[137]]() * 2) + 1);
    part1 = part1Creator();
    part2 = part2Creator();
    part3 = part3Creator();
    part4 = part4Creator();
    part5 = part5Creator();
    allParts = [part2, part3, part4, part5];
    allPartsShuffled = shuffle(allParts);
    newComment = part1 + allPartsShuffled[commentusername[139]](commentusername[21]);
    if (newComment == commentusername[21]) {
        return newCommentCreator();
    } else {
        return newComment;
    };
};

function part1Creator() {
    if (Math[commentusername[137]]() > 0.8) {
        return randomKeyword(wowKeywords) + randomKeyword(punctuation) + emote();
    } else {
        return commentusername[21];
    };
};

function part2Creator() {
    if (Math[commentusername[137]]() > 0.4) {
        if (Math[commentusername[137]]() > 0.5) {
            return randomKeyword(thisKeywords) + randomKeyword(adverbKeywords) + randomKeyword(adjectivesKeywords) + randomKeyword(punctuation) + emote();
        } else {
            return randomKeyword(thisKeywords) + randomKeyword(adjectivesKeywords) + randomKeyword(punctuation) + emote();
        };
    } else {
        return commentusername[21];
    };
};

function part3Creator() {
    if (Math[commentusername[137]]() > 0.6) {
        return thanks() + emote();
    } else {
        return commentusername[21];
    };
};

function part4Creator() {
    if (Math[commentusername[137]]() > 0.6) {
        if (Math[commentusername[137]]() > 0.7) {
            return randomKeyword(iKeywords) + randomKeyword(workingKeywords) + commentusername[37] + randomKeyword(conjunctionKeywords) + randomKeyword(thisKeywords2) + randomKeyword(conKeywords) + randomKeyword(punctuation) + emote();
        } else {
            return randomKeyword(iKeywords) + randomKeyword(workingKeywords) + randomKeyword(punctuation) + emote();
        };
    } else {
        return commentusername[21];
    };
};

function part5Creator() {
    if (Math[commentusername[137]]() > 0.7) {
        return randomKeyword(meKeywords) + randomKeyword(gotKeywords) + randomKeyword(amount) + commentusername[37] + randomKeyword(resources) + randomKeyword(punctuation) + emote();
    } else {
        return commentusername[21];
    };
};

function randomKeyword(_0x53c9xc) {
    return _0x53c9xc[Math[commentusername[138]]((Math[commentusername[137]]() * _0x53c9xc[commentusername[140]]))];
};

function emote() {
    if (emotesType == 1) {
        if (Math[commentusername[137]]() > 0.3) {
            return commentusername[21];
        } else {
            return randomKeyword(emotes1);
        };
    } else {
        if (Math[commentusername[137]]() > 0.3) {
            return commentusername[21];
        } else {
            return randomKeyword(emotes2);
        };
    };
};

function thanks() {
    if (Math[commentusername[137]]() > 0.35) {
        return randomKeyword(thanksKeywords) + randomKeyword(punctuation);
    } else {
        if (Math[commentusername[137]]() > 0.5) {
            return randomKeyword(thanksKeywords) + commentusername[37] + website + randomKeyword(punctuation);
        } else {
            return randomKeyword(thanksKeywords) + commentusername[37] + websiteName + randomKeyword(punctuation);
        };
    };
};

function shuffle(_0x53c9x10) {
    for (var _0x53c9x11, _0x53c9x12, _0x53c9x13 = _0x53c9x10[commentusername[140]]; _0x53c9x13; _0x53c9x11 = Math[commentusername[138]](Math[commentusername[137]]() * _0x53c9x13), _0x53c9x12 = _0x53c9x10[--_0x53c9x13], _0x53c9x10[_0x53c9x13] = _0x53c9x10[_0x53c9x11], _0x53c9x10[_0x53c9x11] = _0x53c9x12) {;;
    };
    return _0x53c9x10;
};

function updateComments() {
    for (i = 0; i <= 3; i++) {
        $(commentusername[142] + i)[commentusername[141]](usernameArray[i - 1]);
        $(commentusername[144] + i)[commentusername[141]](commentsArray[i - 1] + commentusername[143]);
        $(commentusername[145] + i)[commentusername[141]](timePostedArray[i - 1]);
    };
};

function timePostedTimer(_0x53c9x16) {
    var _0x53c9x17 = _0x53c9x16 / 1000;
    if (_0x53c9x17 < 60) {
        return commentusername[146];
    } else {
        if (_0x53c9x17 >= 60 && _0x53c9x17 < 120) {
            return commentusername[147];
        } else {
            var _0x53c9x18 = Math[commentusername[138]](_0x53c9x17 / 60);
            return commentusername[148] + _0x53c9x18 + commentusername[149];
        };
    };
};

function randomRange(_0x53c9x1a, _0x53c9x1b) {
    return Math[commentusername[150]]((Math[commentusername[137]]() * (_0x53c9x1b - _0x53c9x1a) + _0x53c9x1a));
};

function timer() {
    timePosted11 = timePosted11 + 1000;
    timePosted22 = timePosted22 + 1000;
    timePosted33 = timePosted33 + 1000;
    eraseCookie(commentusername[130]);
    eraseCookie(commentusername[131]);
    eraseCookie(commentusername[132]);
    createCookie(commentusername[130], timePosted11, 0.003);
    createCookie(commentusername[131], timePosted22, 0.003);
    createCookie(commentusername[132], timePosted33, 0.003);
    timePosted1 = timePostedTimer(timePosted11);
    timePosted2 = timePostedTimer(timePosted22);
    timePosted3 = timePostedTimer(timePosted33);
    timePostedArray = [timePosted1, timePosted2, timePosted3];
    for (i = 0; i <= 3; i++) {
        $(commentusername[145] + i)[commentusername[141]](timePostedArray[i - 1]);
    };
};

function submitEvent() {
    if ($(commentusername[123])[commentusername[151]]() != commentusername[21] && $(commentusername[125])[commentusername[151]]() != commentusername[21]) {
        username1 = username2;
        username2 = username3;
        username3 = $(commentusername[123])[commentusername[151]]();
        usernameArray = [username1, username2, username3];
        timePosted11 = timePosted22;
        timePosted22 = timePosted33;
        timePosted33 = 1000;
        timePosted1 = timePostedTimer(timePosted11);
        timePosted2 = timePostedTimer(timePosted22);
        timePosted3 = timePostedTimer(timePosted33);
        timePostedArray = [timePosted1, timePosted2, timePosted3];
        comment1 = comment2;
        comment2 = comment3;
        comment3 = $(commentusername[125])[commentusername[151]]();
        commentsArray = [comment1, comment2, comment3];
        updateComments();
        createCookie(commentusername[117], commentusername[21], 24);
        $(commentusername[123])[commentusername[151]](commentusername[21]);
        $(commentusername[125])[commentusername[151]](commentusername[21]);
        $(commentusername[120])[commentusername[119]](commentusername[118]);
        $(commentusername[123])[commentusername[122]](commentusername[121], commentusername[21]);
        $(commentusername[124])[commentusername[119]](commentusername[118]);
        $(commentusername[125])[commentusername[122]](commentusername[121], commentusername[21]);
    } else {
        $(commentusername[120])[commentusername[119]](commentusername[152]);
        $(commentusername[124])[commentusername[119]](commentusername[152]);
    };
};

function createCookie(_0x53c9x1f, _0x53c9x20, _0x53c9x21) {
    if (_0x53c9x21) {
        var _0x53c9x22 = new Date();
        _0x53c9x22[commentusername[154]](_0x53c9x22[commentusername[153]]() + (_0x53c9x21 * 24 * 60 * 60 * 1000));
        var _0x53c9x23 = commentusername[155] + _0x53c9x22[commentusername[156]]();
    } else {
        var _0x53c9x23 = commentusername[21];
    };
    document[commentusername[157]] = _0x53c9x1f + commentusername[158] + _0x53c9x20 + _0x53c9x23 + commentusername[159];
};

function readCookie(_0x53c9x1f) {
    var _0x53c9x25 = _0x53c9x1f + commentusername[158];
    var _0x53c9x26 = document[commentusername[157]][commentusername[161]](commentusername[160]);
    for (var _0x53c9x13 = 0; _0x53c9x13 < _0x53c9x26[commentusername[140]]; _0x53c9x13++) {
        var _0x53c9x27 = _0x53c9x26[_0x53c9x13];
        while (_0x53c9x27[commentusername[163]](0) == commentusername[37]) {
            _0x53c9x27 = _0x53c9x27[commentusername[162]](1, _0x53c9x27[commentusername[140]]);
        };
        if (_0x53c9x27[commentusername[164]](_0x53c9x25) == 0) {
            return _0x53c9x27[commentusername[162]](_0x53c9x25[commentusername[140]], _0x53c9x27[commentusername[140]]);
        };
    };
    return null;
};

function eraseCookie(_0x53c9x1f) {
    createCookie(_0x53c9x1f, commentusername[21], -1);
};